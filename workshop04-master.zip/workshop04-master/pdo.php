<?php
$pdo = new PDO('mysql:host=sql12.freesqldatabase.com;port=3306;dbname=sql12256794', 
   'sql12256794', 'r5d6pZ8NWG');
// See the "errors" folder for details...
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);



